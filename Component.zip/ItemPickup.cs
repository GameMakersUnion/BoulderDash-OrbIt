﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace OrbItProcs
{
    public class $safeitemname$ : Component
    {
        public const mtypes CompType = mtypes.none;
        public override mtypes compType { get { return CompType; } set { } }
        public $safeitemname$() : this(null) { }
        public $safeitemname$(Node parent)
        {
            this.parent = parent;

        }

    }
}
